const UseStaticData = () => {
  return <div></div>;
};

export default UseStaticData;
