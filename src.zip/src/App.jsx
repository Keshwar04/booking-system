import AppRoutes from "./route/appRoutes";

const App = () => <AppRoutes />;

export default App;
