const Flight = () => {
  return <div className="">Flight</div>;
};

export default Flight;
